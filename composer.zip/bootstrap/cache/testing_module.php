<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Testing\\Providers\\TestingServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Testing\\Providers\\TestingServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);